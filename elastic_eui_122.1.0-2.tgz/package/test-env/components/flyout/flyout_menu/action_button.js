"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MenuActionButton = void 0;
var _extends2 = _interopRequireDefault(require("@babel/runtime/helpers/extends"));
var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime/helpers/objectWithoutProperties"));
var _react = _interopRequireDefault(require("react"));
var _button = require("../../button");
var _tool_tip = require("../../tool_tip");
var _react2 = require("@emotion/react");
var _excluded = ["toolTipContent", "toolTipProps"];
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */
var MenuActionButton = exports.MenuActionButton = function MenuActionButton(_ref) {
  var action = _ref.action;
  var toolTipContent = action.toolTipContent,
    toolTipProps = action.toolTipProps,
    buttonProps = (0, _objectWithoutProperties2.default)(action, _excluded);
  var button = (0, _react2.jsx)(_button.EuiButtonIcon, (0, _extends2.default)({}, buttonProps, {
    // The menu bar sets these props itself so every action looks the same.
    // Anything set here also belongs in `EuiFlyoutMenuOwnedActionProps`.
    color: "text",
    size: "xs",
    display: "empty",
    iconSize: "m",
    isSelected: undefined
  }));
  return toolTipContent ? (0, _react2.jsx)(_tool_tip.EuiToolTip, (0, _extends2.default)({
    content: toolTipContent,
    disableScreenReaderOutput: true
  }, toolTipProps), button) : button;
};